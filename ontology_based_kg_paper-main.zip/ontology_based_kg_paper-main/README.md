# ontology_based_kg_paper
